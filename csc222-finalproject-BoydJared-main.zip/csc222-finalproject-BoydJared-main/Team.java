import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

public class Team extends MotoItem {

    /** instance variables */
    private boolean factorySupport;
    private double budget;
    private String manager;

    // initialize scanner
    static Scanner input = new Scanner(System.in);

    /** constructor */
    public Team(String name, String manufacturer, boolean factorySupport, double budget, String manager) {

        super(name, manufacturer);
        this.factorySupport = factorySupport;
        this.budget = budget;
        this.manager = manager;

    }
    // ends constructor

    /** subclass methods */
    // create editTeam method
    public static void editTeam(ArrayList<Team> teams) {
        // check if ArrayList contains data
        if (teams.isEmpty()) {
            System.out.println("Team roster is empty. Please add data to the list.");
            return;
        }

        // prompt for team name
        String teamName = Main.prompt(input, "Enter name of team to edit (case sensitive): ");

        // initialize a "found" flag to check if team has been found
        boolean found = false;

        // setting up booleans for while loop
        boolean fs = false;
        boolean valid = false;

        // if team exists, output current data and prompt for edits
        for (Team team : teams) {
            if (team.getName().equals(teamName)) {
                // output current details
                System.out.println("\n" + teamName + " " + " found! Current data is as follows:");
                team.displayDetails();

                // prompt for new values
                String newName = Main.prompt(input, "\nEnter new team name: ");
                String newManufacturer = Main.prompt(input, "Enter new team manufacturer: ");

                // while loop to check for valid input
                while (!valid) {
                    String factorySupport = Main.prompt(input, "Factory Support? (yes/no): ").toLowerCase();
                    if (factorySupport.equals("yes")) {
                        fs = true;
                        valid = true; // sets 'valid' boolean to 'true' to exit loop
                    }
                    else if (factorySupport.equals("no")) {
                        valid = true;
                    }
                    else {
                        System.out.println("Invalid input. Please enter 'yes' or 'no'.");
                    }
                } // ends while loop

                double newBudget = Main.promptDouble(input, "Enter new budget value: ");
                String newManager = Main.prompt(input, "Enter new team manager: ");

                // set bike parameters to newly input values and exit loop
                team.setManufacturer(newManufacturer);
                team.setName(newName);
                team.setFactorySupport(fs);
                team.setBudget(newBudget);
                team.setManager(newManager);
                System.out.println(newName + " has been successfully edited!");
                found = true;
                break;
            } // ends if statement
        } // ends for loop

        // otherwise, output 'Could not find team. Please try again.' and prompt again for team
        if (!found) {
            System.out.println("Could not find '" + teamName + "'. Please try again.");
            editTeam(teams);
        }
    }
    // ends editTeam method

    // create removeTeam method
    public static void removeTeam(ArrayList<Team> teams) {
        // check if ArrayList contains data
        if (teams.isEmpty()) {
            System.out.println("Team roster is empty. Please add data to the list.");
            return;
        }

        // prompt for team name
        String teamName = Main.prompt(input, "Enter team name to remove (case sensitive): ");

        // initialize a "found" flag to check if team has been found
        boolean found = false;

        // if team exists, output current data and prompt for removal confirmation
        for (Team team : teams) {
            if (team.getName().equals(teamName)) {
                // output current details
                System.out.println("\n" + teamName + " found! Current data is as follows:");
                team.displayDetails();

                // while loop for input handling within the switch statement
                boolean valid = false;
                while (!valid) {
                    String confirm = Main.prompt(input, "\nType 'confirm' to remove " + team.getName() + " from the database, or press 'enter' to return to menu: ").trim().toLowerCase();
                    switch (confirm) {
                        case "confirm" -> {
                            teams.remove(team);
                            System.out.println(teamName + " has been successfully removed from the roster.");
                            valid = true;
                        } // ends confirm case
                        case "" -> {
                            System.out.println("Returning to main menu.");
                            valid = true;
                        } // ends blank case
                        default -> {
                            System.out.println("Please type 'confirm' or press the 'enter' key.");
                        } // ends default
                    } // ends switch statement
                } // ends while loop

                found = true; // set 'found' to true
                break; // exit for loop immediately after removing data
            } // ends if statement
        } // ends for loop

        // otherwise, output 'Could not find team. Please try again.' and prompt again for name
        if (!found) {
            System.out.println("Could not find '" + teamName + "'. Please try again.");
            removeTeam(teams);
        } // ends if statement
    }
    // ends removeTeam method

    // create teamSearch method
    public static void teamSearch(ArrayList<Team> teams) {
        // check if ArrayList contains data
        if (teams.isEmpty()) {
            System.out.println("Team roster is empty. Please add data to the list.");
            return;
        }

        // prompt for team name
        String teamName = Main.prompt(input, "Enter team name to search for (case sensitive): ");

        // initialize a "found" flag to check if team has been found
        boolean found = false;

        // if team exists, output current data
        for (Team team : teams) {
            if (team.getName().equals(teamName)) {
                // output current details
                System.out.println("\n" + teamName + " found! Current data is as follows:");
                team.displayDetails();
                found = true;
                break;
            } // ends if statement
        } // ends for loop

        // otherwise, output 'Could not find team. Please try again.' and prompt again for name
        if (!found) {
            System.out.println("Could not find '" + teamName + "'. Please try again.");
            teamSearch(teams);
        } // ends if statement
    }
    // ends teamSearch method

    // create exportTeams method
    public static void exportTeams(ArrayList<Team> teams) {
        // check if ArrayList contains data
        if (teams.isEmpty()) {
            System.out.println("Team roster is empty. Please add data to the list.");
            return;
        }

        // prompt for export by factorySupport, manufacturer, or export all teams
        String exportType = Main.promptTeamExport(input);

        // export designated team list to CSV file
        switch (exportType) {
            case "all" -> {

                // initialize filepath
                String file = ("src/data/team_data(" + exportType + ").csv");

                try {

                    // initialize PrintWriter
                    PrintWriter fileWriter = new PrintWriter(file);

                    // csv file header
                    fileWriter.println("Name,Manufacturer,Factory Support?,Budget,Manager");

                    for (Team team : teams) {
                        fileWriter.println(team.getName() + "," + team.getManufacturer() + "," + team.getFactorySupport() + "," + team.getBudget() + "," + team.getManager());
                    }

                    // close PrintWriter and output success message
                    fileWriter.close();
                    System.out.println("Data has been successfully exported to: " + file);
                } catch (FileNotFoundException e) {
                    System.out.println("Unable to create file. Error message: " + e.getMessage());
                } // ends try-catch
            } // ends all case
            case "factory support" -> {

                // fs boolean initialization for while loop
                boolean fs = false;

                // while loop to check for valid input
                while (true) {
                    String factorySupport = Main.prompt(input, "yes - Export All Teams with Factory Support\nno - Export All Teams Without Factory Support:\n").toLowerCase();
                    if (factorySupport.equals("yes")) {
                        fs = true;
                        break;
                    }
                    else if (factorySupport.equals("no")) {
                        break;
                    }
                    else {
                        System.out.println("Invalid input. Please enter 'yes' or 'no'.");
                    }
                } // ends while loop

                String file = ("src/data/team_data(factory_" + fs + ").csv");

                try {
                    PrintWriter fileWriter = new PrintWriter(file);
                    // csv file header
                    fileWriter.println("Name,Manufacturer,Factory Support?,Budget,Manager");

                    for (Team team : teams) {
                        if (fs && team.getFactorySupport()) {
                            fileWriter.println(team.getName() + "," + team.getManufacturer() + "," + team.getFactorySupport() + "," + team.getBudget() + "," + team.getManager());
                        }
                        else if (!fs && !team.getFactorySupport()) {
                            fileWriter.println(team.getName() + "," + team.getManufacturer() + "," + team.getFactorySupport() + "," + team.getBudget() + "," + team.getManager());
                        } // ends if-elseif statement
                    } // ends for loop

                    // close PrintWriter and output success message
                    fileWriter.close();
                    System.out.println("Data has been successfully exported to: " + file);
                } catch (FileNotFoundException e) {
                    System.out.println("Unable to create file. Error message: " + e.getMessage());
                } // ends try-catch
            } // ends factory support case
            case "manufacturer" -> {
                String manufacturer = Main.prompt(input, "Enter Manufacturer to Export (case sensitive): ");
                String file = ("src/data/team_data(" + manufacturer + ").csv");

                try {
                    PrintWriter fileWriter = new PrintWriter(file);

                    // csv file header
                    fileWriter.println("Name,Manufacturer,Factory Support?,Budget,Manager");

                    for (Team team : teams) {
                        if (team.getManufacturer().equals(manufacturer)) {
                            fileWriter.println(team.getName() + "," + team.getManufacturer() + "," + team.getFactorySupport() + "," + team.getBudget() + "," + team.getManager());
                        } // ends if statement
                    } // ends for loop

                    // close PrintWriter and output success message
                    fileWriter.close();
                    System.out.println("Data has been successfully exported to: " + file);
                } catch (FileNotFoundException e) {
                    System.out.println("Unable to create file. Error message: " + e.getMessage());
                } // ends try-catch
            }
        } // ends switch
    }
    // ends exportTeams method

    // create listAll method
    public static void listAll(ArrayList<Team> teams) {
        // list all teams currently stored within the database
        if (teams.isEmpty()) {
            System.out.println("Team roster is empty. Please add data to the list.");
            return;
        }
        for (Team team : teams) {
            team.displayDetails();
        }
        System.out.println("-".repeat(20));
    }

    /** getters/setters */
    public boolean getFactorySupport() {
        return factorySupport;
    }
    public double getBudget() {
        return budget;
    }
    public String getManager() {
        return manager;
    }
    // end of getters

    public void setFactorySupport(boolean factorySupport) {
        this.factorySupport = factorySupport;
    }
    public void setBudget(double budget) {
        this.budget = budget;
    }
    public void setManager(String manager) {
        this.manager = manager;
    }
    // end of setters

    /** create override display/toString method */
    @Override
    public void displayDetails() {

        super.displayDetails();
        System.out.println("Factory support?: " + factorySupport);
        System.out.printf("Budget: $" + "%,.2f", budget);
        System.out.println("\nManager: " + manager);

    }
    // ends override display method
} // ends Team class
