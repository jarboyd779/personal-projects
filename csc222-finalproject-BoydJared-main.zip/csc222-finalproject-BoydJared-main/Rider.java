import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

public class Rider extends MotoItem {

    /** instance variables */
    private int number;
    private String bike;
    private String category; // changed from class to category, since 'class' is a builtin function of Java

    // initialize scanner
    static Scanner input = new Scanner(System.in);

    /** constructor */
    public Rider(String name, String manufacturer, int number, String bike, String category) {

        super(name, manufacturer);
        this.number = number;
        this.bike = bike;
        this.category = category;

    }
    // ends constructor

    /** subclass methods */
    // create editRider method
    public static void editRider(ArrayList<Rider> riders) {
        // check if the ArrayList contains data
        if (riders.isEmpty()) {
            System.out.println("Rider roster is empty. Please add data to the list.");
            return;
        }

        // prompt for rider name to edit
        String riderName = Main.prompt(input, "Enter name of the rider to edit (case sensitive): ");

        // initialize a "found" flag to check if rider has been found
        boolean found = false;

        // if rider exists, output existing data and prompt for edits
        for (Rider rider : riders) {
            if (rider.getName().equals(riderName)) {
                // output current details
                System.out.println("\n" + riderName + " found! Current data is as follows:");
                rider.displayDetails();

                // prompt for new values
                String newName = Main.prompt(input, "\nEnter new name of the rider: ");
                String newManufacturer = Main.prompt(input, "Enter new manufacturer: ");
                String newBike = Main.prompt(input, "Enter new bike: ");
                int newNumber = Main.promptInt(input, "Enter new number: ");
                String newCategory = Main.prompt(input, "Enter new class: ");

                // set rider parameters to newly input values and exit loop
                rider.setName(newName);
                rider.setManufacturer(newManufacturer);
                rider.setBike(newBike);
                rider.setNumber(newNumber);
                rider.setCategory(newCategory);
                System.out.println(newName + " has been successfully edited!");
                found = true;
                break;
            } // ends if statement
        } // ends for loop

        // otherwise, output 'Could not find rider name. Please try again' and prompt again for rider name
        if (!found) {
            System.out.println("Could not find '" + riderName + "'. Please try again.");
            editRider(riders);
        } // ends if statement
    }
    // ends editRider method

    // create removeRider method
    public static void removeRider(ArrayList<Rider> riders) {
        // check if the ArrayList contains data
        if (riders.isEmpty()) {
            System.out.println("Rider roster is empty. Please add data to the list.");
            return;
        }
        
        // prompt for rider name to remove
        String riderName = Main.prompt(input, "Enter name of the rider to remove (case sensitive): ");

        // initialize a "found" flag to check if rider has been found
        boolean found = false;

        // if rider exists, output existing data and prompt for removal confirmation
        for (Rider rider : riders) {
            if (rider.getName().equals(riderName)) {
                // output current details
                System.out.println("\n" + riderName + " found! Current data is as follows:");
                rider.displayDetails();
                
                // while loop for input handling within the switch statement
                boolean valid = false;
                while (!valid) {
                    String confirm = Main.prompt(input, "\nType 'confirm' to remove " + rider.getName() + " from the database, or press 'enter' to return to menu: ").trim().toLowerCase();
                    switch (confirm) {
                        case "confirm" -> {
                            riders.remove(rider);
                            System.out.println(riderName + " has been successfully removed from the roster.");
                            valid = true;
                        } // ends confirm case
                        case "" -> {
                            System.out.println("Returning to main menu.");
                            valid = true;
                        } // ends blank case
                        default -> {
                            System.out.println("Please type 'confirm' or press the 'enter' key.");
                        } // ends default
                    } // ends switch statement
                } // ends while loop
                
                found = true; // set 'found' to true
                break; // exit for loop immediately after removing data
            } // ends if statement
        } // ends for loop
        
        // otherwise, output 'Could not find rider name. Please try again' and prompt again for rider name   
        if (!found) {
            System.out.println("Could not find '" + riderName + "'. Please try again.");
            removeRider(riders);
        } // ends if statement
    }
    // ends removeRider method

    // create riderSearch method
    public static void riderSearch(ArrayList<Rider> riders) {
        // check if the ArrayList contains data
        if (riders.isEmpty()) {
            System.out.println("Rider roster is empty. Please add data to the list.");
            return;
        }

        // prompt for rider name to search for
        String riderName = Main.prompt(input, "Enter name of the rider to search for (case sensitive): ");

        // initialize a "found" flag to check if rider has been found
        boolean found = false;

        // if rider exists, output existing data
        for (Rider rider : riders) {
            if (rider.getName().equals(riderName)) {
                // output current details
                System.out.println("\n" + riderName + " found! Current data is as follows:");
                rider.displayDetails();
                found = true;
            } // ends if statement
        } // ends for loop

        // otherwise, output 'Could not find rider name. Please try again' and prompt again for rider name
        if (!found) {
            System.out.println("Could not find '" + riderName + "'. Please try again.");
            riderSearch(riders);
        } // ends if statement
    }
    // ends riderSearch method

    // create exportRiders method
    public static void exportRiders(ArrayList<Rider> riders) {
        // check if the ArrayList contains data
        if (riders.isEmpty()) {
            System.out.println("Rider roster is empty. Please add data to the list.");
            return;
        }

        // prompt for export by category or export all riders
        String exportType = Main.promptRiderExport(input);

        // export designated rider list to CSV file
        try {

            // initialize filepath
            String file = ("src/data/rider_data(" + exportType + ").csv");

            // initialize PrintWriter
            PrintWriter fileWriter = new PrintWriter(file);

            // csv file header
            fileWriter.println("Name,Number,Class,Manufacturer,Bike");

            // switch statement to handle export logic
            switch (exportType) {
                case "all" -> {
                    // export all riders in the database
                    for (Rider rider : riders) {
                        fileWriter.println(rider.getName() + "," + rider.getNumber() + "," + rider.getCategory() + "," + rider.getManufacturer() + "," + rider.getBike());
                    } // ends for loop
                } // ends all case
                case "250" -> {
                    // export all 250 riders in the database
                    for (Rider rider : riders) {
                        if (rider.getCategory().equals("250")) {
                            fileWriter.println(rider.getName() + "," + rider.getNumber() + "," + rider.getCategory() + "," + rider.getManufacturer() + "," + rider.getBike());
                        } // ends if statement
                    } // ends for loop
                } // ends 250 case
                case "450" -> {
                    // export all 450 riders in the database
                    for (Rider rider : riders) {
                        if (rider.getCategory().equals("450")) {
                            fileWriter.println(rider.getName() + "," + rider.getNumber() + "," + rider.getCategory() + "," + rider.getManufacturer() + "," + rider.getBike());
                        } // ends if statement
                    } // ends for loop
                } // ends 450 case
            } // ends switch statement

            /** IMPORTANT: never forget to close the PrintWriter */
            fileWriter.close();
            System.out.println("Data has been successfully exported to: " + file);
        } catch (FileNotFoundException e) {
            System.out.println("Unable to create file. Error message: " + e.getMessage());
        } // ends try-catch
    }
    // ends exportRiders method

    // create listAll method
    public static void listAll(ArrayList<Rider> riders) {
        // check if the ArrayList contains data
        if (riders.isEmpty()) {
            System.out.println("Rider roster is empty. Please add data to the list.");
            return;
        }

        // list all riders currently stored within the database
        for (Rider rider : riders) {
            rider.displayDetails();
        }
        System.out.println("-".repeat(20));
    }

    /** getters/setters */
    public int getNumber() {
        return number;
    }
    public String getBike() {
        return bike;
    }
    public String getCategory() {
        return category;
    }
    // ends getters

    public void setNumber(int number) {
        this.number = number;
    }
    public void setBike(String bike) {
        this.bike = bike;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    // ends setters

    /** create override display/toString method */
    @Override
    public void displayDetails() {

        super.displayDetails();
        System.out.println("Bike: " + bike);
        System.out.println("Number: " + number);
        System.out.println("Category: " + category);

    }
    // ends override display method
} // ends Rider class