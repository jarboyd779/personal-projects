import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

public class Bike extends MotoItem {

    /** instance variables */
    private int size;
    private double power;
    private double torque;

    // initialize scanner
    static Scanner input = new Scanner(System.in);

    /** constructor */
    public Bike(String name, String manufacturer, int size, double power, double torque) {

        super(name, manufacturer);
        this.size = size;
        this.power = power;
        this.torque = torque;

    }
    // ends constructor

    /** subclass methods */
    // create editBike method
    public static void editBike(ArrayList<Bike> bikes) {
        // check if ArrayList contains data
        if (bikes.isEmpty()) {
            System.out.println("Motorcycle roster is empty. Please add data to the list.");
            return;
        }

        // prompt for bike make/model
        String bikeManufacturer = Main.prompt(input, "Enter make of the motorcycle to edit (case sensitive): ");
        String bikeName = Main.prompt(input, "Enter model of the motorcycle to edit (case sensitive): ");

        // initialize a "found" flag to check if bike has been found
        boolean found = false;

        // if bike exists, output current data and prompt for edits
        for (Bike bike : bikes) {
            if (bike.getManufacturer().equals(bikeManufacturer) && bike.getName().equals(bikeName)) {
                // output current details
                System.out.println("\n" + bikeManufacturer + " " + bikeName + " found! Current data is as follows:");
                bike.displayDetails();

                // prompt for new values
                String newManufacturer = Main.prompt(input, "\nEnter new manufacturer: ");
                String newName = Main.prompt(input, "Enter new model name: ");
                int newSize = Main.promptInt(input, "Enter new engine size: ");
                double newPower = Main.promptDouble(input, "Enter new horsepower value: ");
                double newTorque = Main.promptDouble(input, "Enter new torque value: ");

                // set bike parameters to newly input values and exit loop
                bike.setManufacturer(newManufacturer);
                bike.setName(newName);
                bike.setSize(newSize);
                bike.setPower(newPower);
                bike.setTorque(newTorque);
                System.out.println(newManufacturer + " " + newName + " has been successfully edited!");
                found = true;
                break;
            } // ends if statement
        } // ends for loop

        // otherwise, output 'Could not find motorcycle. Please try again.' and prompt again for make/model
        if (!found) {
            System.out.println("Could not find '" + bikeManufacturer + " " + bikeName + "'. Please try again.");
            editBike(bikes);
        } // ends if statement
    }
    // ends editBike method

    // create removeBike method
    public static void removeBike(ArrayList<Bike> bikes) {
        // check if ArrayList contains data
        if (bikes.isEmpty()) {
            System.out.println("Motorcycle roster is empty. Please add data to the list.");
            return;
        }

        // prompt for bike make/model
        String bikeManufacturer = Main.prompt(input, "Enter make of the motorcycle to remove (case sensitive): ");
        String bikeName = Main.prompt(input, "Enter model of the motorcycle to remove (case sensitive): ");

        // initialize a "found" flag to check if bike has been found
        boolean found = false;

        // if bike exists, output current data and prompt for removal confirmation
        for (Bike bike : bikes) {
            if (bike.getManufacturer().equals(bikeManufacturer) && bike.getName().equals(bikeName)) {
                // output current details
                System.out.println("\n" + bikeManufacturer + " " + bikeName + " found! Current data is as follows:");
                bike.displayDetails();

                // while loop for input handling within the switch statement
                boolean valid = false;
                while (!valid) {
                    String confirm = Main.prompt(input, "\nType 'confirm' to remove " + bike.getManufacturer() + " " + bike.getName() + " from the database, or press 'enter' to return to menu: ").trim().toLowerCase();
                    switch (confirm) {
                        case "confirm" -> {
                            bikes.remove(bike);
                            System.out.println(bikeManufacturer + bikeName + " has been successfully removed from the roster.");
                            valid = true;
                        } // ends confirm case
                        case "" -> {
                            System.out.println("Returning to main menu.");
                            valid = true;
                        } // ends blank case
                        default -> {
                            System.out.println("Please type 'confirm' or press the 'enter' key.");
                        } // ends default
                    } // ends switch statement
                } // ends while loop

                found = true; // set 'found' to true
                break; // exit for loop immediately after removing data
            } // ends if statement
        } // ends for loop

        // otherwise, output 'Could not find motorcycle. Please try again' and prompt again for make/model
        if (!found) {
            System.out.println("Could not find '" + bikeManufacturer + " " + bikeName + "'. Please try again.");
            removeBike(bikes);
        } // ends if statement
    }
    // ends removeBike method

    // create bikeSearch method
    public static void bikeSearch(ArrayList<Bike> bikes) {
        // check if ArrayList contains data
        if (bikes.isEmpty()) {
            System.out.println("Motorcycle roster is empty. Please add data to the list.");
            return;
        }

        // prompt for bike make/model
        String bikeManufacturer = Main.prompt(input, "Enter make of the motorcycle to edit (case sensitive): ");
        String bikeName = Main.prompt(input, "Enter model of the motorcycle to edit (case sensitive): ");

        // initialize a "found" flag to check if bike has been found
        boolean found = false;

        // if bike exists, output current data
        for (Bike bike : bikes) {
            if (bike.getManufacturer().equals(bikeManufacturer) && bike.getName().equals(bikeName)) {
                // output current details
                System.out.println("\n" + bikeManufacturer + " " + bikeName + " found! Current data is as follows:");
                bike.displayDetails();
                found = true;
            } // ends if statement
        } // ends for loop

        // otherwise, output 'Could not find motorcycle. Please try again.' and prompt again for make/model
        if (!found) {
            System.out.println("Could not find '" + bikeManufacturer + " " + bikeName + "'. Please try again.");
            bikeSearch(bikes);
        } // ends if statement
    }
    // ends bikeSearch method

    // create exportBikes method
    public static void exportBikes(ArrayList<Bike> bikes) {
        // check if the ArrayList contains data
        if (bikes.isEmpty()) {
            System.out.println("Motorcycle roster is empty. Please add data to the list.");
            return;
        }

        // prompt for export by engine size, manufacturer, or export all bikes
        String exportType = Main.promptBikeExport(input);

        // export designated rider list to CSV file
        switch (exportType) {
            case "all" -> {

                // initialize filepath
                String file = ("src/data/bike_data(" + exportType + ").csv");

                try {

                    // initialize PrintWriter
                    PrintWriter fileWriter = new PrintWriter(file);

                    // csv file header
                    fileWriter.println("Make,Model,Engine Size,Horsepower,Torque");

                    for (Bike bike : bikes) {
                        fileWriter.println(bike.getManufacturer() + "," + bike.getName() + "," + bike.getSize() + "," + bike.getPower() + "," + bike.getTorque());
                    }

                    // close PrintWriter and output success message
                    fileWriter.close();
                    System.out.println("Data has been successfully exported to: " + file);
                } catch (FileNotFoundException e) {
                    System.out.println("Unable to create file. Error message: " + e.getMessage());
                } // ends try-catch
            } // ends all case
            case "engine size" -> {
                int size = Main.promptInt(input, "Enter Engine Size (250 or 450): ");
                if (size == 250 || size == 450) {
                    String file = ("src/data/bike_data(" + size + ").csv");

                    try {
                        PrintWriter fileWriter = new PrintWriter(file);

                        // csv file header
                        fileWriter.println("Make,Model,Engine Size,Horsepower,Torque");

                        for (Bike bike : bikes) {
                            if (bike.getSize() == size) {
                                fileWriter.println(bike.getManufacturer() + "," + bike.getName() + "," + bike.getSize() + "," + bike.getPower() + "," + bike.getTorque());
                            } // ends if statement
                        } // ends for loop

                        // close PrintWriter and output success message
                        fileWriter.close();
                        System.out.println("Data has been successfully exported to: " + file);
                    } catch (FileNotFoundException e) {
                        System.out.println("Unable to create file. Error message: " + e.getMessage());
                    } // ends try-catch
                } // ends if statement
            } // ends engine size case
            case "manufacturer" -> {
                String manufacturer = Main.prompt(input, "Enter Manufacturer to Export (case sensitive): ");
                String file = ("src/data/bike_data(" + manufacturer + ").csv");

                try {
                    PrintWriter fileWriter = new PrintWriter(file);

                    // csv file header
                    fileWriter.println("Make,Model,Engine Size,Horsepower,Torque");

                    for (Bike bike : bikes) {
                        if (bike.getManufacturer().equals(manufacturer)) {
                            fileWriter.println(bike.getManufacturer() + "," + bike.getName() + "," + bike.getSize() + "," + bike.getPower() + "," + bike.getTorque());
                        } // ends if statement
                    } // ends for loop

                    // close PrintWriter and output success message
                    fileWriter.close();
                    System.out.println("Data has been successfully exported to: " + file);
                } catch (FileNotFoundException e) {
                    System.out.println("Unable to create file. Error message: " + e.getMessage());
                } // ends try-catch
            } // ends manufacturer case
        } // ends switch statement
    }
    // ends exportBikes method

    // create listAll method
    public static void listAll(ArrayList<Bike> bikes) {
        // list all bikes currently stored within the database
        if (bikes.isEmpty()) {
            System.out.println("Bike roster is empty. Please add data to the list.");
            return;
        }
        for (Bike bike : bikes) {
            bike.displayDetails();
        }
        System.out.println("-".repeat(20));
    }

    /** getters/setters */
    public int getSize() {
        return size;
    }
    public double getPower() {
        return power;
    }
    public double getTorque() {
        return torque;
    }
    // end of getters

    public void setSize(int size) {
        this.size = size;
    }
    public void setPower(double power) {
        this.power = power;
    }
    public void setTorque(double torque) {
        this.torque = torque;
    }
    // end of setters

    /** create override display/toString method */
    @Override
    public void displayDetails() {


        super.displayDetails();
        System.out.println("Engine size: " + this.size + "cc");
        System.out.printf("Engine power: " + "%.1f", this.power);
        System.out.printf("\nEngine torque: " + "%.1f", this.torque);
        System.out.println();

    }
    // ends override display method
} // ends Bike class
