import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        /** initializing ArrayLists for each category */
        ArrayList<Rider> riders = new ArrayList<>();
        ArrayList<Bike> bikes = new ArrayList<>();
        ArrayList<Team> teams = new ArrayList<>();

        // initialize scanner
        Scanner input = new Scanner(System.in);

        int choice;

        /** do/while for menu loop; as long as choice is not equal to 0, the loop will run */
        do {
            // print statement to display text-based menu
            System.out.println(
                    "***Welcome to the SMX Roster Management System!***\nPlease choose one of the following options:" +
                            "\n1. - Add Data" +
                            "\n2. - Remove Data" +
                            "\n3. - Edit Currently Existing Data" +
                            "\n4. - List All Currently Existing Data" +
                            "\n5. - Remove All Currently Existing Data" +
                            "\n6. - Search" +
                            "\n7. - Export Data to CSV File" +
                            "\n0. - Exit\n" +
                            "-".repeat(20)
            );

            // read input for switch statement
            choice = readInt(input, "Choice: ");

            // switch statement for menu navigation/operation
            switch (choice) {
                case 1:
                    // ask user what to add
                    String add = promptType(input);

                    // logic for input handling
                    if (add.equals("rider")) {
                        String name = prompt(input, "Rider Name: ");
                        String manufacturer = prompt(input, "Manufacturer: ");
                        String bike = prompt(input, "Bike: ");
                        int number = promptInt(input, "Number: ");
                        String group = prompt(input, "Class: ");

                        // create new object in riders ArrayList with user-input values
                        Rider r = new Rider(name, manufacturer, number, bike, group);
                        riders.add(r);
                        System.out.println("Rider " + r.getName() + " successfully added!");
                        break;
                    }
                    else if (add.equals("bike")) {
                        String manufacturer = prompt(input, "Make: ");
                        String name = prompt(input, "Model: ");
                        int size = promptInt(input, "Engine Size: ");
                        double power = promptDouble(input, "Horsepower: ");
                        double torque = promptDouble(input, "Torque: ");

                        // create new object in bikes ArrayList with user-input values
                        Bike b = new Bike(name, manufacturer, size, power, torque);
                        bikes.add(b);
                        System.out.println("The " + b.getManufacturer() + " " + b.getName() + " has been successfully added!");
                        break;
                    }
                    else if (add.equals("team")) {
                        String name = prompt(input, "Team Name: ");
                        String manufacturer = prompt(input, "Manufacturer: ");

                        // setting up booleans for while loop
                        boolean fs = false;
                        boolean valid = false;

                        // while loop to check for valid input
                        while (!valid) {
                            String factorySupport = prompt(input, "Factory Support? (yes/no): ").toLowerCase();
                            if (factorySupport.equals("yes")) {
                                fs = true;
                                valid = true; // sets 'valid' boolean to 'true' to exit loop
                            }
                            else if (factorySupport.equals("no")) {
                                valid = true;
                            }
                            else {
                                System.out.println("Invalid input. Please enter 'yes' or 'no'.");
                            }
                        } // ends while loop

                        double budget = promptDouble(input, "Budget: ");
                        String manager = prompt(input, "Manager: ");

                        // create new object in teams ArrayList with user-input values
                        Team t = new Team(name, manufacturer, fs, budget, manager);
                        teams.add(t);
                        System.out.println(t.getName() + " successfully added!");
                        break;
                    }
                case 2:
                    // ask user what to remove
                    String remove = promptType(input);

                    // method calls
                    if (remove.equals("rider")) {
                        Rider.removeRider(riders);
                        break;
                    }
                    else if (remove.equals("bike")) {
                        Bike.removeBike(bikes);
                        break;
                    }
                    else if (remove.equals("team")) {
                        Team.removeTeam(teams);
                        break;
                    }
                    break;
                case 3:
                    // ask user what to edit
                    String edit = promptType(input);

                    // method calls
                    if (edit.equals("rider")) {
                        Rider.editRider(riders);
                        break;
                    }
                    else if (edit.equals("bike")) {
                        Bike.editBike(bikes);
                        break;
                    }
                    else if (edit.equals("team")) {
                        Team.editTeam(teams);
                        break;
                    }
                case 4:
                    // ask user what to list
                    String list = promptType(input);

                    // method calls
                    if (list.equals("rider")) {
                        Rider.listAll(riders);
                        break;
                    }
                    else if (list.equals("bike")) {
                        Bike.listAll(bikes);
                        break;
                    }
                    else if (list.equals("team")) {
                        Team.listAll(teams);
                        break;
                    }
                    break;
                case 5:
                    // ask user what to clear
                    String removeAll = promptType(input);

                    // ArrayList method calls
                    if (removeAll.equals("rider")) {
                        riders.clear();
                        System.out.println("Rider roster has been successfully cleared!");
                        break;
                    }
                    else if (removeAll.equals("bike")) {
                        bikes.clear();
                        System.out.println("Motorcycle roster has been successfully cleared!");
                        break;
                    }
                    else if (removeAll.equals("team")) {
                        teams.clear();
                        System.out.println("Team roster has been successfully cleared!");
                        break;
                    }
                    break;
                case 6:
                    // ask user what to search for
                    String search = promptType(input);

                    // method calls
                    if (search.equals("rider")) {
                        Rider.riderSearch(riders);
                        break;
                    }
                    else if (search.equals("bike")) {
                        Bike.bikeSearch(bikes);
                        break;
                    }
                    else if (search.equals("team")) {
                        Team.teamSearch(teams);
                        break;
                    }
                    break;
                case 7:
                    // ask user what to export
                    String export = promptType(input);

                    // method calls
                    if (export.equals("rider")) {
                        Rider.exportRiders(riders);
                        break;
                    }
                    else if (export.equals("bike")) {
                        Bike.exportBikes(bikes);
                        break;
                    }
                    else if (export.equals("team")) {
                        Team.exportTeams(teams);
                        break;
                    }
                    break;
                case 0:
                    // exit switch and close program
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println();
        } while (choice != 0);

    } // ends main method/driver

    /** thought i could use this from IDE 3, seems like a convenient method for the menu */
    // read integer and check for invalid input, reprompting until valid
    private static int readInt(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }

    /** took the following prompt methods from Week 6 for use with submenus, modifying them to meet the needs of this project */
    public static String prompt(Scanner sc, String message) {
        System.out.print(message);
        String line = sc.nextLine();
        return line.trim();
    } // end prompt

    public static String promptRiderExport(Scanner sc) {
        String choice = null;
        boolean valid = false;

        // while loop for error handling
        while (!valid) {
            choice = prompt(sc, "Select Category to Export (type your answer):\n250\n450\nAll\n\nYour Answer: ").trim().toLowerCase();

            // if user input is valid, exit the loop
            if (choice.equals("250") ||  choice.equals("450") || choice.equals("all")) {
                valid = true;
            }
            else {
                System.out.println("Please enter '250', '450' or 'All'.");
            } // ends if-else
        } // ends while loop

        return choice; // return user input
    } // end prompt

    public static String promptBikeExport(Scanner sc) {
        String choice = null;
        boolean valid = false;

        // while loop for error handling
        while (!valid) {
            choice = prompt(sc, "Select Category to Export (type your answer):\nEngine Size\nManufacturer\nAll\n\nYour Answer: ").trim().toLowerCase();

            // if user input is valid, exit the loop
            if (choice.equals("engine size") ||  choice.equals("manufacturer") || choice.equals("all")) {
                valid = true;
            }
            else {
                System.out.println("Please enter 'Engine Size', 'Manufacturer' or 'All'.");
            } // ends if-else
        } // ends while loop

        return choice; // return user input
    } // end prompt

    public static String promptTeamExport(Scanner sc) {
        String choice = null;
        boolean valid = false;

        // while loop for error handling
        while (!valid) {
            choice = prompt(sc, "Select Category to Export (type your answer):\nFactory Support\nManufacturer\nAll\n\nYour Answer: ").trim().toLowerCase();

            // if user input is valid, exit the loop
            if (choice.equals("factory support") ||  choice.equals("manufacturer") || choice.equals("all")) {
                valid = true;
            }
            else {
                System.out.println("Please enter 'factory support', 'Manufacturer' or 'All'.");
            } // ends if-else
        } // ends while loop

        return choice; // return user input
    } // end prompt

    // added this to only accept 'rider', 'bike', or 'team' as input to simplify error handling within the switch statement
    public static String promptType(Scanner sc) {
        String choice = null;
        boolean valid = false;

        // while loop for error handling
        while (!valid) {
            choice = prompt(sc, "Select Category (type your answer):\nRider\nBike\nTeam\n\nYour Answer: ").trim().toLowerCase();

            // if user input is valid, exit the loop
            if (choice.equals("rider") ||  choice.equals("bike") || choice.equals("team")) {
                valid = true;
            }
            else {
                System.out.println("Please enter 'rider', 'bike' or 'team'.");
            } // ends if-else
        } // ends while loop

        return choice; // return user input
    } // end prompt

    // cleaned up this promptInt method to include a try-catch with additional error handling
    public static int promptInt(Scanner sc, String message) {

        System.out.print(message);
        String line = sc.nextLine();
        String trimmed = line.trim();

        // this try-catch allows for cleaner flexibility over the if-else that I was using before
        try {
            int value = Integer.parseInt(trimmed);

            // ensure the input falls within a specific value
            if (value < 1 || value > 999) {
                System.out.println("Invalid input. Value must be between 1 and 999.");
                return promptInt(sc, message);
            }

            return value;
        } catch (NumberFormatException e) {
            System.out.println("Please enter a whole number.");
            return promptInt(sc, message);
        }
    } // end promptInt

    public static double promptDouble(Scanner sc, String message) {
        while (true) {
            System.out.print(message);
            String line = sc.nextLine();
            String trimmed = line.trim();

            if (trimmed.isEmpty()) {
                return 0.0;
            } // end if empty

            try {
                double value = Double.parseDouble(trimmed);
                return value;
            } catch (NumberFormatException nfe) {
                System.out.println("Please enter a valid number (e.g., 12.50).");
            } // end try/catch
        } // end while
    } // end promptDouble
} // ends Main class