public class MotoItem {

    /** instance variables */
    private String name;
    private String manufacturer;

    /** constructor */
    public MotoItem(String name, String manufacturer) {

        this.name = name;
        this.manufacturer = manufacturer;

    }
    // end constructor

    /** getters/setters */
    public String getName() {
        return name;
    }
    public String getManufacturer() {
        return manufacturer;
    }
    // end of getters

    public void setName(String name) {
        this.name = name;
    }
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }
    // end of setters

    /** display/toString method */
    public void displayDetails() {

        System.out.println("-".repeat(20));
        System.out.println("Name: " + this.name);
        System.out.println("Manufacturer: " + this.manufacturer);

    }
    // end display method

} // ends MotoItem class
