Very basic keylogger that records keystrokes and creates newlines with each 'Enter' key press.
Writes all inputs to a .txt file named 'heard' within the program directory.

Needs to be compiled as an executable that will run as a background process for the most effective use.

Not tested on any Unix/Linux operating systems.
